from flask import Flask,request, render_template, request, jsonify
import mysql.connector as connection
import logging as lg
import pymongo

lg.basicConfig(filename="E:/stored2.log",level=lg.INFO,format='%(asctime)s - %(levelname)s  - %(message)s')
app=Flask(__name__)

class MangoDbDatabase:
    # table creation
    @staticmethod
    @app.route('/table1', methods=['POST'])  # for calling the API from Postman/SOAPUI4
    def create_table1():
        try:
            '''table  is creation postman 
            through mysql database1 using 
            flask  and rest api
            '''
            if (request.method == 'POST'):
                path = request.json['path']
                lg.info("localhost connection")
                databasename = request.json['databasename']
                lg.info("data base is created")
                table_name = request.json["table_name"]
                lg.info("user name and password")
                '''
                connection is established python to 
                mango db compass

                '''
                client= pymongo.MongoClient(path)
                db_name =  databasename
                database = client[db_name]
                collection = database[table_name]
            return jsonify("table is created sucessfully")
        except Exception as e:
            lg.error("error message")
            lg.exception(str(e))

    @staticmethod
    @app.route('/bulkinsert1', methods=['POST'])  # for calling the API from Postman/SOAPUI4
    def data_bulkinsert1():
        try:
            '''insert the data into mangodb compass
            through postman

            '''
            if (request.method == 'POST'):
                path = request.json['path']
                lg.info("localhost connection")
                databasename = request.json['databasename']
                record=request.json['record']
                lg.info("bulkinesert the data ")
                table_name = request.json["table_name"]
                lg.info("user name and password")
                '''
                connection is established python to 
                mango db compass

                '''
                client = pymongo.MongoClient(path)
                db_name = databasename
                database = client[db_name]
                collection = database[table_name]
                collection.insert_many(record)    #insert many are one


            return jsonify("bulk data inserted sucessfully")
        except Exception as p:

            lg.error("error message")
            lg.exception(str(p))

    @staticmethod
    @app.route('/insert1', methods=['POST'])  # for calling the API from Postman/SOAPUI4
    def data_insert1():
        try:
            '''insert the data into mangodb compass
            through postman

            '''
            if (request.method == 'POST'):
                path = request.json['path']
                lg.info("localhost connection")
                databasename = request.json['databasename']
                record = request.json['record']
                lg.info("inesert the data ")
                table_name = request.json["table_name"]
                lg.info("user name and password")
                '''
                connection is established python to 
                mango db compass

                '''
                client = pymongo.MongoClient(path)
                db_name = databasename
                database = client[db_name]
                collection = database[table_name]
                collection.insert_one(record)  # insert many are one

            return jsonify("data inserted sucessfully")
        except Exception as p:

            lg.error("error message")
            lg.exception(str(p))

    @staticmethod
    @app.route('/delete1', methods=['POST'])  # for calling the API from Postman/SOAPUI4
    def data_delete1():
        try:
            '''dlete the data into mangodb compass
            through postman

            '''
            if (request.method == 'POST'):
                path = request.json['path']
                lg.info("localhost connection")
                databasename = request.json['databasename']
                record = request.json['record']
                lg.info("delete the data ")
                table_name = request.json["table_name"]
                lg.info("user name and password")
                '''
                connection is established python to 
                mango db compass

                '''
                client = pymongo.MongoClient(path)
                db_name = databasename
                database = client[db_name]
                collection = database[table_name]
                collection.delete_one(record) # insert many are one

            return jsonify("deleted the data  sucessfully")
        except Exception as p:

            lg.error("error message")
            lg.exception(str(p))

    @staticmethod
    @app.route('/update1', methods=['POST'])  # for calling the API from Postman/SOAPUI4
    def data_update1():
        try:
            '''update the data into mangodb compass
            through postman

            '''
            if (request.method == 'POST'):
                path = request.json['path']
                lg.info("localhost connection")
                databasename = request.json['databasename']
                record = request.json['record']
                new=request.json['new']
                lg.info("update  the data ")
                table_name = request.json["table_name"]
                lg.info("user name and password")
                '''
                connection is established python to 
                mango db compass

                '''
                client = pymongo.MongoClient(path)
                db_name = databasename
                database = client[db_name]
                collection = database[table_name]
                collection.update_many(record,new)  # update the data


            return jsonify("update  the data  sucessfully")
        except Exception as p:

            lg.error("error message")
            lg.exception(str(p))


if __name__ =="__main__":
    app.run()