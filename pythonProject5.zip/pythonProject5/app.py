from flask import Flask,request, render_template, request, jsonify
import mysql.connector as connection
import logging as lg
import csv


# i send the all the postman postman code in blow program


lg.basicConfig(filename="E:/stored1.log",level=lg.INFO,format='%(asctime)s - %(levelname)s  - %(message)s')



app = Flask(__name__)


class MysqlDatabase:
#table creation
    @staticmethod
    @app.route('/table', methods=['POST'])  # for calling the API from Postman/SOAPUI4
    def create_table():
        try:
            '''table  is creation postman 
            through mysql database1 using 
            flask  and rest api
            '''
            if (request.method == 'POST'):
                localhost = request.json['localhost']
                lg.info("localhost connection")
                tablename=request.json['tablename']
                lg.info("data base is created")
                user = request.json['user']
                password = request.json['password']
                lg.info("user name and password")
                '''
                connection is established python
                to my sql connector 
                
                '''

                mydb = connection.connect(host=localhost, database='database1',user=user, passwd=password, use_pure=True)
                lg.info("connection between  python and mysql")
                query= f"create table database1.{tablename}"
                cursor = mydb.cursor()
                cursor.execute(query)
                cursor = mydb.cursor()
                lg.debug("query executed successfully")
            return jsonify("table is created sucessfully")
        except Exception as e:
            mydb.close()
            lg.error("error message")
            lg.exception(str(e))


#insert the data
    @staticmethod
    @app.route('/insert', methods=['POST'])  # for calling the API from Postman/SOAPUI4
    def data_insert():
        try:
            '''insert the data into data base 
            through postman using flask api 
            
            '''
            if (request.method == 'POST'):
                localhost = request.json['localhost']
                lg.info("localhost connection")
                insert_data=request.json['insert_data']
                lg.info("inesert the data")
                user = request.json['user']
                password = request.json['password']
                lg.info("user name and password")
                '''
                connection is established python
                to my sql connector 
                
                '''

                mydb1 = connection.connect(host=localhost, database='database1',user=user, passwd=password, use_pure=True)
                lg.info("connection between  python and mysql")
                query= f"{insert_data}"
                cursor1 = mydb1.cursor()
                cursor1.execute(query)
                lg.debug("query executed successfully")
                mydb1.commit()
            return jsonify("data inserted sucessfully")
        except Exception as p:
            mydb1.close()
            lg.error("error message")
            lg.exception(str(p))



    # update the data
    @staticmethod
    @app.route('/update', methods=['POST'])  # for calling the API from Postman/SOAPUI4
    def data_update():
        try:
            '''update the data into data base 
            through postman using flask api 

            '''
            if (request.method == 'POST'):
                localhost = request.json['localhost']
                lg.info("localhost connection")
                update_data = request.json['update_data']
                lg.info("update the data")
                user = request.json['user']
                password = request.json['password']
                lg.info("user name and password")
                '''
                connection is established python
                to my sql connector 

                    '''

                mydb2 = connection.connect(host=localhost, database='database1', user=user, passwd=password,
                                              use_pure=True)
                lg.info("connection between  python and mysql")
                query = f"{update_data}"
                cursor2 = mydb2.cursor()
                cursor2.execute(query)
                lg.debug("query executed successfully")
                mydb2.commit()
            return jsonify("data updated sucessfully")
        except Exception as p:
            mydb2.close()
            lg.error("error message")
            lg.exception(str(p))


    #delete the data
    @staticmethod
    @app.route('/delete', methods=['POST'])  # for calling the API from Postman/SOAPUI4
    def data_delete():
        try:
            '''update the data into data base 
            through postman using flask api 

            '''
            if (request.method == 'POST'):
                localhost = request.json['localhost']
                lg.info("localhost connection")
                delete_data = request.json['delete_data']
                lg.info("delete the data")
                user = request.json['user']
                password = request.json['password']
                lg.info("user name and password")
                '''
                connection is established python
                to my sql connector 

                '''

                mydb2 = connection.connect(host=localhost, database='database1', user=user, passwd=password,
                                       use_pure=True)
                lg.info("connection between  python and mysql")
                query = f"{delete_data}"
                cursor2 = mydb2.cursor()
                cursor2.execute(query)
                lg.debug("query executed successfully")
                mydb2.commit()
            return jsonify("data deleted sucessfully")
        except Exception as p:
            mydb2.close()
            lg.error("error message")
            lg.exception(str(p))

    #bulk inserted
    @staticmethod
    @app.route('/bulkinsert', methods=['POST'])  # for calling the API from Postman/SOAPUI4
    def data_bulk_insert():
        try:
            '''bulk insert the data the data into data base 
            through postman using flask api 

            '''
            if (request.method == 'POST'):
                localhost = request.json['localhost']
                lg.info("localhost connection")
                path = request.json['path']
                bulk_data=request.json['bulk_data']
                lg.info("bulk inserted  the data")
                user = request.json['user']
                password = request.json['password']
                lg.info("user name and password")
                '''
                connection is established python
                to my sql connector  and bulk data 
                inserted 

                '''

                mydb2 = connection.connect(host="localhost", database='sangamesh45688', user=user, passwd=password,
                                           use_pure=True)

                with open(path, 'r') as p:
                    for i in enumerate(csv.reader(p, delimiter='\n')):
                        if i[0] == 0:
                            continue
                        lg.info(str(i[1][0].split(';')))
                        query = f"{bulk_data}"
                        cur2 = mydb2.cursor()
                        cur2.execute(query, i[1][0].split(';'))
                mydb2.commit()
            return jsonify("bulk data inserted sucessfully")
        except Exception as p:
            mydb2.close()
            lg.error("error message")
            lg.exception(str(p))



if __name__ =="__main__":
    app.run(debug=True)


#mysql code
#table creation
'''{"localhost":"localhost",
"user":"root",
"password":"root189",
"tablename":"studentdetails(x1 INT(10),x2 VARCHAR(20),x3 DATE)"
}
#data inserted
{"localhost":"localhost",
"user":"root",
"password":"root189",
"insert_data":"Insert into database1.studentdetails values(56,'sanga','2021-06-03')"
}

#update the data
{"localhost":"localhost",
"user":"root",
"password":"root189",
"update_data":"UPDATE database1.studentdetails SET x2 ='satish'  WHERE x1 =85"
}

#delete the data
{
    "localhost":"localhost",
"user":"root",
"password":"root189",
"delete_data":"delete from  database1.studentdetails where x1=85"
}


#bulk data table cretion
{"localhost":"localhost",
"user":"root",
"password":"root189",
"tablename"="create table carbon_nanotubes1(Chiralindice1 varchar(20),Chiralindice2 varchar(20),Initialatomiccoordinate  varchar(20), Initialatomic1coordinate  varchar(20),Initialatomic2coordinate  varchar(20),Calculatedatomiccoordinates  varchar(20), Calculatedatomic1coordinates varchar(20), Calculatedatomic2coordinates varchar(20)"
}

}

#bulk inseted data
{
"localhost":"localhost",
"user":"root",
"password":"root189",
 "path":"C:/Users/SANGMESH/Desktop/Full Stack class practise/carbon_nanotubes.csv",
 "bulk_data":"insert into  database1.carbon_nanotubes1 values(%s,%s,%s,%s,%s,%s,%s,%s)"

}'''









